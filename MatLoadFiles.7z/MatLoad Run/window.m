function [sun,tran ] = window(h,pm,ta,wall_angle,sfw_angle,F )

%   Detailed explanation goes here
a_a = 18;             
a_r = 8;             
Ra  = 1/a_a; 
Rr  = 1/a_r;
tr  = 20;          
td1 = 0.8;    
td2 = td1;      
ad1 = 0.08;    
ad2 = ad1;    
K   = 1.71;  

rsj = zeros(1,24);
Id1 = zeros(1,24);  
Id2 = zeros(1,24);
tran = zeros(1,24); 
sun = zeros(1,24);
for ii = 1:24 
    %[rsj, Id0,Idh] = wall_calc(h ,pm,wall_angle,sfw_angle); 
    [rsj,Id1,Id2] = wall_calc(h ,pm,wall_angle,sfw_angle(ii));
    tran(ii) = K*F*(ta(ii)-tr);     
    sun(ii)= F*(Id1(ii)*(td1+(Ra/(Ra+Rr))*ad1)+Id2(ii)*(td2+(Ra/(Ra+Rr)*ad2)));  % p32 2-62
end
end
