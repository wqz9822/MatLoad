

t   = zeros(1,24);    
t_k = zeros(1,24);      
ea  = zeros(1,24);        

omega = zeros(1,24);    
h     = zeros(1,24);     
alpha = zeros(1,24);     
m     = zeros(1,24);    
pm    = zeros(1,24);
rsj   = zeros(1,24);     
Id0   = zeros(1,24);  
Idh   = zeros(1,24);  

tz = zeros(1,24);           
qs = zeros(1,24);      	 
qr = zeros(1,24);    
qe = zeros(1,24);       
HG_wall   = zeros(1,24); 
HG_window = zeros(1,24);    

HG_sum = zeros(1,24);
cita   = zeros(1,24);       



filename = 'heat.xlsm';
ta= xlsread(filename, 1,'B8:Y8');   
t_k = ta + 273.15;
ea = xlsread(filename,1,'B10:Y10');  



 
[omega,h,alpha,m,pm] = sun_calc();           

%[rsj, Id0,Idh] = wall_calc(h ,pm,wall_angle,sfw_angle); 
 
[rsj, Id0,Idh] = wall_calc(h ,pm,0,0);        
 
[tz,qs,qr,qe]= t_z( Id0, Idh,Id0+Idh,t_k,ea); 
 
[HG_wall,cita] = h_wave(tz);              
 
%function [sun,tran ] = window(h,pm,ta,wall_angle,sfw_angle,F )
[sun_w,tran_w] = window(h,pm,ta,90, alpha-90, 4.466);
[sun_e,tran_e] = window(h,pm,ta,90, alpha+90, 4.466);
[sun_s,tran_s] = window(h,pm,ta,90, alpha, 1.5288);
HG_window_tran = (tran_w)+ (tran_e)+(tran_s);
HG_window_sun = (sun_w)+ (sun_e)+(sun_s);
HG_sum = (-sun_w-tran_w)+ (-sun_e-tran_e)+(-sun_s-tran_s) - HG_wall;
 
 main_data =[ omega           %1
              h               %2
              alpha           %3
              rsj             %4
              m               %5
              pm              %6
              Id0             %7
              Idh             %8
              Id0+Idh         %9
              ta              %10
              tz              %11
              qs              %12
              qe              %13
              cita            %14
              HG_wall         %15
              HG_window_tran  %16
              HG_window_sun   %17
              HG_sum          %18
            ];
                  
xlswrite(filename,main_data,2,'E3');
 



