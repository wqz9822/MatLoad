function [tz,qs,qr,qe] =t_z( Id0,Idh,Ish,Ta ,ea)
%UNTITLED2 Summary of this function goes here
% Detailed explanation goes here

    a_a = 18;        
    ad1 = 0.4;      
    ad2 = 0.3;       
    Cb = 5.67;       
    pg = 0.2 ;
    cita = 0;        
    eo = 0.4;       
    eg = 0.12;      
    eos = eo;       
    eog = eo*eg;    
    aos = 1;     
    aog = 0;
    
    tz = zeros(1,24);
    qs = zeros(1,24); 
    qr = zeros(1,24);  
    qe = zeros(1,24); 
   
    for ii = 1:24
        Ts = (0.51+0.208*sqrt(ea(ii)))^(0.25)*Ta(ii); %p17 2-27 
        %Ts = (0.51+0.208*sqrt(0.18))^(0.25)*Ta(ii);
        Tg = Ta(ii);
        qs(ii) = ad1*Id0(ii)+ad2*Idh(ii);              % p27 line 1
        qr(ii)= ad2*(pg)*Ish(ii)*(1-(cosd(cita/2))^2); % p27 line 4
        qe(ii) = Cb*eo*(Ta(ii)/100)^4 - Cb*eos*aos*(Ts/100)^4 - Cb*eog*aog*(Tg/100)^4;  % p29 2-54 
    
        tz(ii) = (Ta(ii)-273.15) + (qs(ii)+qr(ii))/a_a - qe(ii)/a_a;  % p29 2-55
    end

end


