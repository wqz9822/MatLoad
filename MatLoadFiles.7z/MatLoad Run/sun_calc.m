function [omega,h,alpha,m,pm] = sun_calc( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

current_year = 2012;
current_month = 12;
current_day = 20;

jd = 117.2;     
s_jd = 120;   
wd = 39.1;   
p = 0.62;    


omega = zeros(1,24);   
alpha = zeros(1,24);  
m     = zeros(1,24); 
pm    = zeros(1,24);

%---------------------------------------------------------------------------------------------
    n = days_calc(12,20);
    n0 = 79.6764 + 0.2422*(current_year-1985) - fix((current_year-1985)/4);
    t= n - n0  ;
    cita = 2*pi*t/(365.2422-0.3);   
    cwj = 0.3723 + 23.2567*sin(cita)+ 0.1149*sin(2*cita)-0.1712*sin(3*cita)-0.758*cos(cita)+0.3656*cos(2*cita)+0.0201*cos(3*cita);

    e = 0.0028 - 1.9857*sin(cita)+9.9059*sin(2*cita)-7.0924*cos(cita)-0.6882*cos(2*cita);
%--------------------------------------------------------------------------------------------   
 for ii = 1:24

      omega(ii) = ((ii-1) + (jd - s_jd)/15 + e/60 -12)*15;                   
      h(ii) = asind(sind(wd)*sind(cwj)+cosd(wd)*cosd(cwj)*cosd(omega(ii)));  
      alpha(ii) = asind(cosd(cwj)*sind(omega(ii))/cosd(h(ii)));             
      m(ii) = 1/sind(h(ii));                                                 
      pm(ii) = p^m(ii);
 end
 
end

function [n] = days_calc(current_month,current_day)
    days = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    n = 0;
    for ii = 1:(current_month-1)
        n = n + days(ii);
    end
    n = n+ current_day;
end


