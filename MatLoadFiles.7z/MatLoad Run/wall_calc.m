function [rsj, Id0,Idh ] = wall_calc( h ,pm,wall_angle,sfw_angle)
%UNTITLED3 Summary of this function goes here


I0 = 1353;       
p = 0.62;       


rsj = zeros(1,24);       
Id0 = zeros(1,24);       
Idh = zeros(1,24);     

for ii = 1:24
  if  (h(ii)<=0 )
    rsj(ii) = 0;
    Id0(ii) = 0;
    Idh(ii) = 0; 
  else
    rsj(ii) = acosd(cosd(wall_angle)*sind(h(ii))+sind(wall_angle)*cosd(h(ii))*cosd(sfw_angle)); % p9 2-7 
    Id0(ii) = I0*pm(ii)*cosd(rsj(ii));  % p15 2-16 
    Idh(ii) = 0.5*I0*sind(h(ii))*(1-pm(ii))/(1-1.4*log(p));  % p15 2-19 
  end
end
 
end
